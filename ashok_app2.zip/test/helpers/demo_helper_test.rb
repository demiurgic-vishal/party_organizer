require 'test_helper'

class DemoHelperTest < ActionView::TestCase
end
