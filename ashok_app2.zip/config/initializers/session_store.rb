# Be sure to restart your server when you modify this file.

PartyOrganiser::Application.config.session_store :cookie_store, key: '_party_organiser_session'
