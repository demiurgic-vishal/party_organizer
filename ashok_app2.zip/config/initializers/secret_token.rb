# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
PartyOrganiser::Application.config.secret_key_base = 'f2079c8a40ff34054ea9859c97db09bfbfb1f221b3d246a0a3ea0eaf5a140239056c4b8d0dbc54fc6ea7f44c4aab84f42659ce5d1cba4e6e0ebf770302521d0c'
