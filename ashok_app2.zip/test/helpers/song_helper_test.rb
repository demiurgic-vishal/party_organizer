require 'test_helper'

class SongHelperTest < ActionView::TestCase
end
