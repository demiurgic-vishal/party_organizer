class Song < ActiveRecord::Base
end
